// components/Layout.js
import { AppBar, Toolbar, Typography, Container, Box } from '@mui/material';
import Link from 'next/link';

export default function Layout({ children }) {
    return (
        <>
            {/* Header */}
            <AppBar position="static">
                <Toolbar>
                    <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                        MyApp
                    </Typography>
                    <nav>
                        <Link href="/" passHref>
                            <Typography variant="button" sx={{ marginRight: 2, color: 'white', textDecoration: 'none' }}>
                                Home
                            </Typography>
                        </Link>
                        <Link href="/register" passHref>
                            <Typography variant="button" sx={{ color: 'white', textDecoration: 'none' }}>
                                Register
                            </Typography>
                        </Link>
                    </nav>
                </Toolbar>
            </AppBar>

            {/* Main Content */}
            <Container maxWidth="lg" sx={{ padding: 4 }}>
                {children}
            </Container>

            {/* Footer */}
            <Box component="footer" sx={{ padding: 2, backgroundColor: 'primary.main', color: 'white', textAlign: 'center' }}>
                <Typography variant="body2">© {new Date().getFullYear()} MyApp. All rights reserved.</Typography>
            </Box>
        </>
    );
}
