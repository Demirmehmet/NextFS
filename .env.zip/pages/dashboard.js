import {useEffect, useState} from 'react';
import {useRouter} from 'next/router';
import Layout from "../components/Layout";
import apiClient from "../lib/axios";

export default function Dashboard() {
    const [user, setUser] = useState(null);
    const [meal, setMeal] = useState('');
    const [calories, setCalories] = useState('');
    const [calorieEntries, setCalorieEntries] = useState([]);
    const [totalCalories, setTotalCalories] = useState(0);
    const router = useRouter();

    useEffect(() => {
        const token = localStorage.getItem('token');

        if (!token) {
            router.push('/');
            return;
        }

        const verifyUser = async () => {
            try {
                const res = await fetch('/api/verifyToken', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({token}),
                });

                if (res.ok) {
                    const data = await res.json();
                    setUser(data.username);
                } else {
                    throw new Error('Token verification failed');
                }
            } catch (error) {
                console.log('Invalid token', error);
                localStorage.removeItem('token');
                router.push('/');
            }
        };

        verifyUser();
        fetchCalorieEntries().then(async r => {
            const data = await r.json();
            setCalorieEntries(data.entries);
            const total = data.entries.reduce((acc, entry) => acc + entry.calories, 0);
            setTotalCalories(total);
        });
    }, []);

    const fetchCalorieEntries = async () => {
        try {
            const response = await apiClient.get('/calorieEntry');
            return response.data.entries; // Handle the data as needed
        } catch (error) {
            console.error('Error fetching calorie entries:', error);
            throw error;
        }
    };

    const createCalorieEntry = async (meal, calories) => {
        try {
            const response = await apiClient.post('/calorieEntry', {
                meal,
                calories,
            });
            return response.data; // Handle the response data as needed
        } catch (error) {
            console.error('Error creating calorie entry:', error);
            throw error;
        }
    };

    const addCalorieEntry = async (e) => {
        e.preventDefault();
        const token = localStorage.getItem('token');

        const res = await createCalorieEntry(JSON.stringify({meal, calories}));

        if (res.ok) {
            const newEntry = await res.json();
            setCalorieEntries([...calorieEntries, newEntry]);
            setTotalCalories(totalCalories + parseInt(calories));
            setMeal('');
            setCalories('');
        }
    };

    return <Layout>
        {user ? `Welcome ${user}` : 'Loading...'}

        <h1>Calorie Tracker</h1>
        <h2>Total Calories Today: {totalCalories}</h2>

        <form onSubmit={addCalorieEntry}>
            <input
                type="text"
                placeholder="Meal"
                value={meal}
                onChange={(e) => setMeal(e.target.value)}
                required
            />
            <input
                type="number"
                placeholder="Calories"
                value={calories}
                onChange={(e) => setCalories(e.target.value)}
                required
            />
            <button type="submit">Add Entry</button>
        </form>

        <h2>Your Entries</h2>
        <ul>
            {calorieEntries.map((entry) => (
                <li key={entry.id}>
                    {entry.meal} - {entry.calories} calories
                </li>
            ))}
        </ul>
    </Layout>;
}
